import numpy as np
import cv2
import serial  # For serial communication
import time
import csv  # For writing to CSV

# Initialize serial communication with Arduino
arduino = serial.Serial('/dev/tty.usbmodem34B7DA649D4C2', 9600)  # Replace with your Arduino's port
time.sleep(2)  # Wait for the connection to establish

# Load Haarcascade Classifiers
faceCascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
smileCascade = cv2.CascadeClassifier('haarcascade_smile.xml')

# Initialize webcam
cap = cv2.VideoCapture(0)

# Open a CSV file in write mode
with open('output.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    # Write the header row
    writer.writerow(['Timestamp', 'Distance (cm)', 'Face Detected', 'Smiling'])

    while True:
        # Read data from Arduino
        distance = None
        if arduino.in_waiting > 0:
            try:
                distance = arduino.readline().decode('utf-8').strip()  # Read distance
                print(f"Distance: {distance} cm")
            except ValueError:
                  print('OOOOOOOPS')
                  continue

        # Read frame from webcam
        ret, img = cap.read()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = faceCascade.detectMultiScale(
            gray,
            scaleFactor=1.3,
            minNeighbors=5,
            minSize=(30, 30)
        )

        face_detected = False
        smiling = False

        for (x, y, w, h) in faces:
            face_detected = True
            cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
            roi_gray = gray[y:y + h, x:x + w]

            smile = smileCascade.detectMultiScale(
                roi_gray,
                scaleFactor=1.5,
                minNeighbors=15,
                minSize=(25, 25),
            )

            for i in smile:
                if len(smile) > 1:
                    smiling = True
                    cv2.putText(img, "Smiling", (x, y - 30), cv2.FONT_HERSHEY_SIMPLEX,
                                2, (0, 255, 0), 3, cv2.LINE_AA)
                    # Send a signal to Arduino if smiling
                    arduino.write(b'S')
                else:
                    # Send 'N' if not smiling
                    arduino.write(b'N')

        # Write the data to the CSV
        timestamp = time.strftime('%Y-%m-%d %H:%M:%S')  # Current timestamp
        writer.writerow([timestamp, distance, face_detected, smiling])

        # Display the frame
        cv2.imshow('video', img)

        k = cv2.waitKey(30) & 0xff
        if k == 27:  # Press 'ESC' to quit
            break

# Cleanup
cap.release()
cv2.destroyAllWindows()
arduino.close()